import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseClient: SupabaseClient | null = null;

// Default credentials provided for the N! GAMES project
const DEFAULT_SUPABASE_URL = 'https://frjmslrygksatugmjzot.supabase.co';
const DEFAULT_SUPABASE_KEY = 'sb_secret_VoBzuy8ijWDIqTLLkmXJNg_VuiBEl4q';

function isValidHttpUrl(str?: string): boolean {
  if (!str) return false;
  try {
    const url = new URL(str);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

function cleanCandidateString(val?: string): string {
  if (!val) return '';
  let str = val.trim();
  // Remove wrapping quotes if present
  if ((str.startsWith('"') && str.endsWith('"')) || (str.startsWith("'") && str.endsWith("'"))) {
    str = str.slice(1, -1).trim();
  }
  return str;
}

function normalizeSupabaseUrl(rawUrl?: string): string {
  let url = cleanCandidateString(rawUrl);
  if (!url) return '';
  
  // If user entered a domain without protocol e.g. "frjmslrygksatugmjzot.supabase.co"
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    if (url.includes('.supabase.') || url.includes('.')) {
      url = 'https://' + url;
    }
  }

  url = url.replace(/\/rest\/v1\/?$/, '');
  url = url.replace(/\/+$/, '');

  if (!isValidHttpUrl(url)) {
    return '';
  }

  return url;
}

function isValidSupabaseKey(key?: string): boolean {
  const clean = cleanCandidateString(key);
  // Valid keys are either JWT (start with eyJ...) or Supabase API keys (start with sb_secret_ or sb_publishable_) or length >= 20 without spaces
  if (!clean || clean.length < 15 || clean.includes(' ')) {
    return false;
  }
  return true;
}

export function resolveSupabaseCredentials(): { url: string; key: string } | null {
  // Try environment variables first
  const envUrlCandidate = normalizeSupabaseUrl(process.env.SUPABASE_URL);
  
  const envKeyCandidate = [
    cleanCandidateString(process.env.SUPABASE_KEY),
    cleanCandidateString(process.env.SUPABASE_SECRET_KEY),
    cleanCandidateString(process.env.SUPABASE_ANON_KEY),
    cleanCandidateString(process.env.SUPABASE_SERVICE_ROLE_KEY),
    cleanCandidateString(process.env.SUPABASE_PUBLISHABLE_KEY),
  ].find(isValidSupabaseKey);

  // If valid environment variables are present, use them
  if (envUrlCandidate && envKeyCandidate) {
    return { url: envUrlCandidate, key: envKeyCandidate };
  }

  // Fallback to default project credentials if available and valid
  if (isValidHttpUrl(DEFAULT_SUPABASE_URL) && isValidSupabaseKey(DEFAULT_SUPABASE_KEY)) {
    return {
      url: envUrlCandidate || DEFAULT_SUPABASE_URL,
      key: envKeyCandidate || DEFAULT_SUPABASE_KEY,
    };
  }

  return null;
}

export function isSupabaseConfigured(): boolean {
  return resolveSupabaseCredentials() !== null;
}

export function getSupabase(): SupabaseClient | null {
  const credentials = resolveSupabaseCredentials();
  if (!credentials) {
    return null;
  }

  if (!supabaseClient) {
    try {
      supabaseClient = createClient(credentials.url, credentials.key, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      });
    } catch (err) {
      console.error('[Supabase] Failed to initialize client:', err);
      return null;
    }
  }

  return supabaseClient;
}
